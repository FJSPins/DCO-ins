# Real-Industrial-Source Static Flexible Job Shop Scheduling Instances

## Dataset overview

This collection contains six static Flexible Job Shop Scheduling Problem (FJSP) instances adapted from five industrial case-study sources. The instances cover customized manufacturing, locomotive and wagon production, aerospace component manufacturing, flexible packaging, and workforce-constrained discrete manufacturing.

Each instance provides ordered job operations, eligible machine or resource alternatives, processing times, and job due dates in a consistent FJSP text format. All jobs are assumed to be available at the beginning of the scheduling horizon.

The instances are derived from published industrial cases and publicly released manufacturing records. To ensure compatibility with a common static FJSP formulation, selected source-specific constraints have been simplified. Consequently, these instances represent adapted industrial scheduling cases rather than exact reproductions of the original industrial optimization problems.

## Instance descriptions

**RW01 — Customized Manufacturing Workshop (7×6)**

Derived from an industrial daily production order reported by Li et al. (2025). The case includes seven jobs, 26 operations, and six machines across milling, drilling, boring, and turning processes. Original machine alternatives, processing times, and due dates are retained. Fixture-related constraints and job release times are omitted. One inconsistent processing-time entry is resolved using a documented conversion assumption.

**RW02 — Locomotive and Wagon Manufacturing (58×41)**

Derived from the real-world industrial instance #43 published by Deliktaş et al. (2024). The original case comprises 58 parts, 269 operations, 41 machines, four manufacturing cells, and four part families. Processing times and due dates are converted from minutes to hours. Cell-specific, transportation, and setup constraints are excluded from the adapted formulation.

**RW03 — Aerospace Component Manufacturing (3×17)**

Based on an aerospace manufacturing case presented by Jiang et al. (2022). The instance includes three jobs, 33 operations, and 17 machines. Original processing times, operation sequences, and eligible machine sets are retained. Lot-splitting and secondary resource constraints are excluded. Due dates are generated using a documented processing-time-based rule.

**RW04 — Extended Aerospace Manufacturing (4×19)**

Combines the three aerospace jobs from Jiang et al. (2022) with an additional urgent job reported by Tian et al. (2023). The extended instance contains four jobs, 52 operations, and 19 machines. Dynamic arrival and breakdown events are removed for static scheduling. Due dates are generated. RW03 and RW04 share their first three jobs and therefore are not independent industrial case studies.

**RW05 — Flexible Packaging Manufacturing (59×15)**

Derived from manufacturing ERP records published by Tarigan et al. (2025). The converted instance contains 59 orders, 237 operations, and 15 machines across printing, lamination, extrusion, slitting, and bag-making processes. Machine eligibility follows published routing and capability information. Processing times are estimated from order quantities and machine-speed parameters, while due times are calculated from original order deadlines using a common calendar origin. The conversion assumptions are recorded separately.

**RW06 — Workforce-Constrained Discrete Manufacturing (10×10)**

Derived from the industrial workshop case in Li et al. (2025). The original case comprises ten jobs, 48 operations, eight physical machines, and eight workers. Two additional virtual resources represent worker-only tasks to enable compatibility with the standard FJSP representation. Original processing-time values and due dates are preserved, while release times and multitasking workforce constraints are simplified.

## Data format

Each file follows the structure:

- Line 1: Number of jobs, number of machines/resources, and average machine flexibility.
- Line 2: Due date of each job.
- Remaining lines: One line per job, containing the number of operations followed by eligible machine–processing-time pairs for each operation.

Machine indices are one-based, and the files are compatible with FJSP parsers supporting floating-point processing times.

## Important limitations

The collection does not preserve all constraints of the original industrial scheduling problems. Some instances involve generated due dates, estimated processing times, or virtual resources. The FJSP files do not include machine-specific energy consumption coefficients. Any energy-aware experiments must separately document the energy model and parameter sources.

Researchers should cite the original industrial case-study publications and datasets, identify the simplifications employed, and comply with the original data licenses when redistributing or reusing these instances.