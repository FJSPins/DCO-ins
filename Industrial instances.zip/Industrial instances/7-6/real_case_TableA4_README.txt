Real-world case converted from Table A4

Jobs: 7
Machines: 6
Operations: 26
Total eligible machine choices: 60
Average flexibility: 2.3076923076923075

Static MO-FJSP adaptation:
1. Only actual jobs J1-J7 are retained.
2. Original eligible machine sets and processing times are retained.
3. Original delivery times are used as due dates:
   123 132 85 180 106 153 87
4. Release times are ignored and all jobs are assumed available at t=0.
5. Fixture constraints and fixture-production tasks are omitted.

Source-table inconsistency:
J1-O14 lists eligible machines M5,M6 but gives three processing-time values:
22, 25, 24.
For the runnable FJS file, M5=22 and M6=25 are used.
The third value 24 is not used.
