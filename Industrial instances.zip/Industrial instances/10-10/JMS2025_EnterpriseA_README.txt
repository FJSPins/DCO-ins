SOURCE: Jiahang Li et al., A multitasking workforce-constrained flexible job shop scheduling problem: An application from a real-world workshop, Journal of Manufacturing Systems 83 (2025) 196-215, Table 11 (p. 212), doi:10.1016/j.jmsy.2025.09.004.

STATIC FJSP ADAPTATION (NOT THE ORIGINAL FJSP-MW PROBLEM):
- 10 actual jobs and 48 operations; J1-J10 listed in Table 11.
- Real machines M1-M8 are retained with their reported processing times.
- Worker-only operations (Aging, Marking, Fitter), which have no machine in the original, are mapped to two VIRTUAL resources M9 and M10 corresponding to workers W5 and W6. Both alternatives retain the one reported processing time. This is a modeling assumption: virtual resources are single-capacity machines, whereas original workers W5 and W6 can multitask (capacity two). Consequently, original worker constraints and multitasking are not preserved; worker constraints on actual machines are also omitted.
- Processing time values and due dates are retained exactly as reported in Table 11 (no scaling). The source table does not explicitly specify the units; DO NOT claim these values are hours unless verified elsewhere. If you want to interpret them as hours, that is an additional explicit assumption.
- All job releases assumed 0 for STATIC FJSP; original release times are [2, 3, 5, 8, 6, 7, 11, 13, 15, 10] (not encoded).
- Original due dates: [74, 144, 117, 166, 114, 80, 174, 65, 110, 153].
- Table 11 prints J1's second operation as O15 (duplicating the final operation label), and the following as O13. It is treated as the SECOND operation O12 in listed row order; its process and time are unchanged.
- Number of operations: 48; total machine options: 137; mean flexibility: 2.854166666667; FJS size: 10 jobs x 10 resources (8 original machines + 2 virtual resources).
- Objective interpretation: makespan and tardiness apply to this simplified static model. No physical energy rates are supplied for virtual resources or actual machines, so an energy objective requires independently specified machine energy parameters; the source case alone does not validate energy consumption.

FJS format: row 1 jobs machines average flexibility; row 2 job due dates; subsequent rows one job: number of operations, and per operation number of eligible resources followed by (resource id, processing time) pairs.
