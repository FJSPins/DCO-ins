Aerospace real-world case adapted from Jiang et al. (2022)

Source: Appendix 1, Tables A1a-A1d and Table A2.

Static MO-FJSP adaptation:
- Jobs retained: G1, G2, G3
- Machines retained: M1-M17
- Original operation order retained
- Original eligible machine sets retained
- Original processing times retained in HOURS
- Lot-splitting is not modeled
- Clamping time, tool-setting time, tool-changing time, forceps/manual-preparation time,
  processing cost, and tool constraints are omitted because the current DCO environment
  does not model them.

Due dates:
The source paper does NOT report due dates.
Generated using D_i = 1.5 * sum_j(min_k p_ijk)
G1 = 33.3450 h
G2 = 30.2550 h
G3 = 43.3200 h

Important source interpretation:
For heat-treatment operations with eligible machines M16 and M17, the source table reports
one common processing time. The same reported time is assigned to both machines:
G2-O3 = 5.2 h and G3-O4 = 4.1 h.

Jobs: 3
Machines: 17
Operations: 33
Eligible machine choices: 106
Average flexibility: 3.212121
