# Synthetic FJSP Instances

## Overview

This directory is intended to contain benchmark instances for the **static flexible job shop scheduling problem (FJSP)**. The supplied example, `6j_3m_001.fjs`, includes job-operation precedence information, eligible machine alternatives, processing times, and job due dates. Each job is assumed to be available at the beginning of the scheduling horizon when using the instances in a static FJSP setting.

The example file contains **6 jobs, 3 machines, 14 operations, and 33 eligible operation–machine assignments**, with an average of **2.357142857** eligible machines per operation. The underlying instance-generation procedure, random seed, and processing-time units are not encoded in the file and should be documented separately if available.

## Instance Naming

The example filename follows the convention:

`<number_of_jobs>j_<number_of_machines>m_<instance_id>.fjs`

For example, `6j_3m_001.fjs` denotes an instance with 6 jobs and 3 machines, identified as instance 001. Other files should be interpreted using their actual contents; this README does not assume that additional instances have already been supplied.

## File Format

The `.fjs` files use a whitespace-delimited, extended FJSP format:

1. **First line:** `number_of_jobs number_of_machines average_flexibility`.
2. **Second line:** one due date per job, in job order.
3. **Remaining lines:** one line per job. Each job line begins with its number of operations. For each operation, the line then specifies the number of eligible machines, followed by `(machine_id, processing_time)` pairs.

In symbolic form, a job line is:

```text
number_of_operations
eligible_count_op1 machine_id time [machine_id time ...]
eligible_count_op2 machine_id time [machine_id time ...]
...
```

The actual job record occupies **one line**; the line breaks above only illustrate the sequence of fields. Operations within each job are processed in their listed order. Machine IDs start at **1**.

### Example: `6j_3m_001.fjs`

The first two lines are:

```text
6 3 2.357142857142857
39 61 65 56 46 46
```

They define 6 jobs, 3 machines, average flexibility of approximately 2.3571, and a due date for each of the 6 jobs.

The first job is encoded as:

```text
2 2 1 7 2 8 1 2 7
```

It contains **two ordered operations**:

- Operation 1: machine 1 (processing time 7) or machine 2 (processing time 8).
- Operation 2: machine 2 only (processing time 7).

The first job has due date **39**.

## Example Instance Summary

| Property | Value |
|---|---:|
| File | `6j_3m_001.fjs` |
| Number of jobs | 6 |
| Number of machines | 3 |
| Total operations | 14 |
| Eligible operation–machine assignments | 33 |
| Average machine flexibility | 33 / 14 = 2.357142857 |
| Job due dates | 39, 61, 65, 56, 46, 46 |

## Scheduling Assumptions and Objective Evaluation

Under the common static FJSP interpretation, all jobs are available at time zero; each operation is assigned to one of its eligible machines; operations of a job obey precedence constraints; and a machine cannot process overlapping operations.

The encoded due dates allow researchers to evaluate tardiness using, for example, total tardiness $\sum_j \max(0, C_j-d_j)$, where $C_j$ is the completion time of job $j$ and $d_j$ is its due date. Makespan can be calculated as $\max_j C_j$.

**Important:** The supplied `.fjs` file does **not** specify machine power ratings, idle-energy coefficients, or other energy-model parameters. Reproducing energy-consumption objectives therefore requires the accompanying experimental energy model, its numerical parameters, and the method for calculating energy consumption. Time units and the generation rule for due dates are likewise not specified within the file.

## Reproducibility and Citation

For reproducible comparisons, users should report the exact instance files, scheduling constraints, random seeds and algorithm settings, objective definitions, and any energy-related parameters. If this collection is used in a publication, cite the associated paper or repository record once these identifiers are available.

The filename and format description above are verified against the supplied example instance; additional dataset-level claims (generation algorithm, total number of files, train/test split, and license) should only be added after verification.
